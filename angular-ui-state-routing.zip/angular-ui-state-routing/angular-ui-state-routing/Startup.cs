﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(angular_ui_state_routing.Startup))]
namespace angular_ui_state_routing
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
